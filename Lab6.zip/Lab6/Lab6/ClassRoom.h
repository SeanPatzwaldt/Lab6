#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include "Student.h"
using namespace std;

class ClassRoom: public Student
{
private:
	string nameOfClass;
	int numOfStudents;
	Student *students;

public:
	ClassRoom();
	~ClassRoom();

	void inputData(ifstream& inFile, string fileName);
	void sortByAverage();
	void sortByLastName();
	double averageGrade();

	void display();
	int getNumStudents();

};