///////////////////////////////////////////////////////////////////////
//                                                                     
// Filename: Student.cpp
// Date: Decemeber 5, 2020
// Programmer: Maryam Abkar,  Lucas Collins, Christian Gruebel,  Sean Patzwaldt, Ahmad Waleed             
//
// Description:
//    defines all functions listed in the student.h file 
/////////////////////////////////////////////////////////////////////////

#include<iostream>
#include<string>
#include"Student.h"

using namespace std;

int Student::studentNumber = 0;

Student::Student()
	//: averageExam(), exams()
{
	studentNumber++;
	//exams = new double[4];
}

Student::~Student()
{
	studentNumber--;
}

void Student::display()
{
	cout << "first name is: " << getFirstName() << endl;
	cout << "last name is: " << getLastName() << endl;
	cout << "the social security number is: " << getSSN() << endl;
	cout << "the exam scores are : " << /*getExams() <<*/ endl;
	double* e = getExams();
	for (int i = 0; i < 4; i++)
	{
		cout << e[i] << endl;
	}
	cout << "the average exam score is: " << getAverageExam() << endl;
	cout << "the student number is: " << getStudentNumber() << endl;

}

///// Getters /////
string Student::getFirstName()
{
	return firstName;
}

string Student::getLastName() 
{
	return lastName;
}

string Student::getSSN()
{
	return SSN;
}

double* Student::getExams()
{
	return exams;

}

double Student::getAverageExam()
{
	double sum = 0;
	for (int i = 0; i < 4; i++)
	{
		sum += exams[i];
	}

	return sum / 4.0;
}

int Student::getStudentNumber()
{
	return studentNumber;
}

///// Setters /////
void Student::setFirstName(string newFirst)
{
	firstName = newFirst;
}

void Student::setLastName(string newLast)
{
	lastName = newLast;
}

void Student::setSSN(string newSSN)
{
	SSN = newSSN;
}

void Student::setExams(double exam1, double exam2, double exam3, double exam4)
{
	exams[0] = exam1;
	exams[1] = exam2;
	exams[2] = exam3;
	exams[3] = exam4;
}

void Student::setAverageExam(double newAvg)
{
	averageExam = newAvg;
}