///////////////////////////////////////////////////////////////////////
//                                                                     
// Filename: ClassRoom.cpp
// Date: Decemeber 5, 2020
// Programmer: Maryam Abkar,  Lucas Collins, Christian Gruebel,  Sean Patzwaldt, Ahmad Waleed             
//
// Description:
//    defines all the classes functions and attributes
/////////////////////////////////////////////////////////////////////////

#include<iostream>
#include<string>
#include <fstream>
#include "ClassRoom.h"

using namespace std;

ClassRoom::ClassRoom()
	: numOfStudents()/*, students()*/
{
	students = new Student[24];
}

ClassRoom::~ClassRoom() 
{

	
	//delete students;
}

void ClassRoom::inputData(ifstream& inFile, string fileName)
{
	string firstName, lastName, SSN;
	int i = 0;
	double exam1, exam2, exam3, exam4;

	inFile.open(fileName, ios::in);
	
	if (inFile.is_open())	
	{
		while (!inFile.eof())
		{
			inFile >> lastName >> firstName >> SSN >> exam1 >> exam2 >> exam3 >> exam4;
			Student student =  Student();

			student.setExams(exam1, exam2, exam3, exam4);
			//student.setExams(exam1, exam2, exam3, exam4);
			student.setSSN(SSN);
			student.setFirstName(firstName);
			student.setLastName(lastName);
			student.setAverageExam(student.getAverageExam());

			students[i] = student;
			/*
			students[i].setExams(exam1, exam2, exam3, exam4);
			students[i]->setSSN(SSN);
			students[i]->setFirstName(firstName);
			students[i]->setLastName(lastName);
			students[i]->setAverageExam(Student::getAverageExam());
			*/
			
			i++;
			numOfStudents++;
		}
	}
	else
	{
		cout << "Error: Couldn't load file." << endl;
	}
}

void ClassRoom::sortByAverage()
{
	for (int i = 0; i < getNumStudents(); i++)
	{
		for (int j = 0; j < getNumStudents() - i - 1; j++)
		{
		if (students[j].getAverageExam() > students[j + 1].getAverageExam())
			{
			Student temp = students[j];
			students[j] = students[j + 1];
			students[j + 1] = temp;
			}
		}	
	}
	cout<<"List sorted by Average\n";
}
void ClassRoom::sortByLastName()
{
for (int i = 0; i < getNumStudents(); i++)
	{
		for (int j = 0; j < getNumStudents() - i - 1; j++)
		{
		if (students[j].getLastName() > students[j + 1].getLastName())
			{
			Student temp = students[j];
			students[j] = students[j + 1];
			students[j + 1] = temp;
			}
		}	
	}
}

double ClassRoom::averageGrade()
{
	double sum = 0.0;
	double average = 0.0;

	for (int i = 0; i < getNumStudents(); i++) 
	{
		sum += students[i].getAverageExam();
	}

	average = sum / getNumStudents();

	return average;

}

void ClassRoom::display()
{
	for (int i = 0; i < getNumStudents(); i++)
	{
		cout << "Student number: "<<students[i].getStudentNumber() << endl;
		students[i].display();
	}
}

int ClassRoom::getNumStudents()
{
	return numOfStudents;
}