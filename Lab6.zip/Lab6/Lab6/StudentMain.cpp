///////////////////////////////////////////////////////////////////////
//                                                                     
// Filename: StudentMain.cpp
// Date: December 5, 2020
// Programmer: Maryam Abkar,  Lucas Collins, Christian Gruebel,  Sean Patzwaldt, Ahmad Waleed             
//
// Description:
//    Description of what the code in the file is meant to do and 
//    how it does what it is meant to do.
/////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include "Student.h"
#include "ClassRoom.h"

using namespace std;
 
int main()
{
	ClassRoom C = ClassRoom();
	ifstream inFile;
	C.inputData(inFile, "students.txt");
	cout << "Sorted List Of Students By Student Average \n ";
	C.sortByAverage();
	cout << "Sorted List Of Students By Student Last Name\n ";
	C.sortByLastName();
	cout << "display all classroom data" << endl;
	C.display();


	system("pause");
	return 0;
}