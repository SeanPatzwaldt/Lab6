//////////////////////////////////////////////////////////////////////
//                                                                     
// Filename: Student.h
// Date: December 5, 2020
// Programmer: Maryam Abkar,  Lucas Collins, Christian Gruebel,  Sean Patzwaldt, Ahmad Waleed                 
//
// Description:
//    lists all the data members and functions of a student object
/////////////////////////////////////////////////////////////////////////
#pragma once
#include <string>
#include <iostream>
using namespace std;

class Student 
{
private:
	string firstName;
	string lastName;
	string SSN;
	double exams[4];
	double averageExam;
	static int studentNumber;

public:
	Student();
	~Student();
	
	//all getter functions
	string getFirstName();
	string getLastName();
	string getSSN();
	//exam array getter
	double * getExams();
	double getAverageExam();
	static int getStudentNumber();

    //all setter functions
	void setFirstName(string newFirst);
	void setLastName(string newLast);
	void setSSN(string newSSN);
	//exam setter function
	void setExams(double exam1, double exam2, double exam3, double exam4);
	void setAverageExam(double newAvg);

	//display all atributes
	void display();

};



